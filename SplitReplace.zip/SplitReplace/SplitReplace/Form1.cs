﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace SplitReplace
{
    public partial class Form1 : Form
    {
        string strIncomingFilePath = string.Empty;
        string strLogFilePath = string.Empty; 
        string strOutputFolder = string.Empty;
        string strProcessedFilePath = string.Empty;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            strIncomingFilePath = ConfigurationManager.AppSettings["incomingfolder"];
            strLogFilePath = ConfigurationManager.AppSettings["logfolder"] + "\\" + "log_" + DateTime.Now.Ticks + ".txt";
            strOutputFolder = ConfigurationManager.AppSettings["outputfolder"];
            strProcessedFilePath = ConfigurationManager.AppSettings["Processed"];
            foreach (string file in Directory.EnumerateFiles(strIncomingFilePath))
            {
                string contents = File.ReadAllText(file);
                string retVal = SplitandReplace(contents, ',', "\"");
                WriteOutputFlatFile(retVal,  Path.GetFileNameWithoutExtension(file) + Path.GetExtension(file));
                MoveFile(file, strProcessedFilePath + "\\" + Path.GetFileNameWithoutExtension(file) + Path.GetExtension(file));
            }


        }
        private string SplitandReplace(string line, char delimeter, string replaceval)
        {
            string strReturnLine = string.Empty;
            try
            {
                string[] strArray = line.Split(delimeter);
                for (int i = 0; i < strArray.Length; i++)
                {
                    string strreplace = strArray[i].Replace(replaceval, "");
                    strReturnLine = strReturnLine + "," + strreplace;
                }
                strReturnLine = "\"" + strReturnLine.TrimStart(',').Replace(",", "\",\"") + "\"";
            }
            catch (Exception ex)
            {
                LogWrite("Error for line:: " + line);
                LogWrite("Error is:: " + ex.Message);
            }
            return strReturnLine;
        }
        private FileInfo GetFileInfo(string strUploadFilePath)
        {
            return new FileInfo(strUploadFilePath);
        }
        public void LogWrite(string message)
        {
            try
            {
                if (File.Exists(strLogFilePath))
                    File.AppendAllText(strOutputFolder, Environment.NewLine + message);
                else
                    File.WriteAllText(strOutputFolder, message);
            }
            catch
            {
            }
        }
        public void WriteOutputFlatFile(string message, string fileName)
        {
            try
            {
                if (File.Exists(strOutputFolder + "\\" + fileName))
                    File.AppendAllText(strOutputFolder + "\\" + fileName, Environment.NewLine + message);
                else
                    File.WriteAllText(strOutputFolder + "\\" + fileName, message);
            }
            catch
            {
            }
        }
        private void MoveFile(string incoming, string destFolder)
        { 
           // string destFileName = String.Concat(Path.GetFileNameWithoutExtension(fi.Name), "_", DateTime.Now.ToString("yyyyMMdd_HHmmss_fff"), ".", fi.Extension);
            File.Move(incoming,  destFolder);
        }

    }
}
