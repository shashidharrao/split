﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace SplitReplaceService
{
    public partial class Service1 : ServiceBase
    {
        string strIncomingFilePath = string.Empty;
        string strLogFilePath = string.Empty;
        string strLogFileName = string.Empty;
        string strOutputFolder = string.Empty;
        string strProcessedFilePath = string.Empty;
        private System.Timers.Timer aTimer;
        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            //To install service
            //open command prompt and run as  an administrator
            //type cd C:\Windows\Microsoft.NET\Framework64\v4.0.30319\
            //type InstallUtil -i  C:\Users\f80469c\Desktop\SplitValues\SplitandReplaceDelimeter\SplitReplaceService\bin\Debug\SplitReplaceService.exe 
            //press enter
            //<<our applicationpath>>** //C:\Users\f80469c\Desktop\SplitValues\SplitandReplaceDelimeter\SplitReplaceService\bin\Debug\SplitReplaceService.exe 
            aTimer = new System.Timers.Timer(10000);
            // Hook up the Elapsed event for the timer.
            aTimer.Elapsed += new ElapsedEventHandler(OnTimedEvent);
            // Set the Interval to 2 seconds (2000 milliseconds).
            aTimer.Interval = 2 * 60000;
            aTimer.Enabled = true;
        }
        private void OnTimedEvent(object source, ElapsedEventArgs e)
        {
            startProcess();
        }
        protected override void OnStop()
        {
        }
        private void startProcess()
        {
            strIncomingFilePath = ConfigurationManager.AppSettings["incomingfolder"];
            strLogFilePath = ConfigurationManager.AppSettings["logfolder"] + "\\" + "log_" + DateTime.Now.Ticks + ".txt";
            strOutputFolder = ConfigurationManager.AppSettings["outputfolder"];
            strProcessedFilePath = ConfigurationManager.AppSettings["Processed"];
            foreach (string file in Directory.EnumerateFiles(strIncomingFilePath))
            {
                string contents = File.ReadAllText(file);
                string retVal = SplitandReplace(contents, ',', "\"");
                WriteOutputFlatFile(retVal, Path.GetFileNameWithoutExtension(file) + Path.GetExtension(file));
                MoveFile(file, strProcessedFilePath + "\\" + Path.GetFileNameWithoutExtension(file) + Path.GetExtension(file));
            }
        }
        private string SplitandReplace(string line, char delimeter, string replaceval)
        {
            string strReturnLine = string.Empty;
            try
            {
                string[] strArray = line.Split(delimeter);
                for (int i = 0; i < strArray.Length; i++)
                {
                    string strreplace = strArray[i].Replace(replaceval, "");
                    strReturnLine = strReturnLine + "," + strreplace;
                }
                strReturnLine = "\"" + strReturnLine.TrimStart(',').Replace(",", "\",\"") + "\"";
            }
            catch (Exception ex)
            {
                LogWrite("Error for line:: " + line);
                LogWrite("Error is:: " + ex.Message);
            }
            return strReturnLine;
        }
        private FileInfo GetFileInfo(string strUploadFilePath)
        {
            return new FileInfo(strUploadFilePath);
        }
        public void LogWrite(string message)
        {
            try
            {
                if (File.Exists(strLogFilePath))
                    File.AppendAllText(strOutputFolder, Environment.NewLine + message);
                else
                    File.WriteAllText(strOutputFolder, message);
            }
            catch
            {
            }
        }
        public void WriteOutputFlatFile(string message, string fileName)
        {
            try
            {
                if (File.Exists(strOutputFolder + "\\" + fileName))
                    File.AppendAllText(strOutputFolder + "\\" + fileName, Environment.NewLine + message);
                else
                    File.WriteAllText(strOutputFolder + "\\" + fileName, message);
            }
            catch
            {
            }
        }
        private void MoveFile(string incoming, string destFolder)
        {
            // string destFileName = String.Concat(Path.GetFileNameWithoutExtension(fi.Name), "_", DateTime.Now.ToString("yyyyMMdd_HHmmss_fff"), ".", fi.Extension);
            File.Move(incoming, destFolder);
        }
    }
}
