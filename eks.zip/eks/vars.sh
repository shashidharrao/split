# Override variables from vars.defaults here
export CLUSTER_NAME=taadev-cluster
export NUM_NODES=2
export MIN_NUM_NODES=2
export MAX_NUM_NODES=3
export WORKER_INSTANCE_TYPE=t3a.xlarge
export AWS_REGION=us-west-2
export EKS_DENALI_ENABLED=true
