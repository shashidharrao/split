#!/bin/bash
CLUSTER_NAME=$1

# BUFFER_SIZE is used to paginate calls to describe-tags which can take only 20 arns per request
BUFFER_SIZE=20

# Query to find resources with tag: kubernetes.io/cluster/$CLUSTER_NAME
CLUSTER_QUERY="TagDescriptions[?Tags[?Key==\`kubernetes.io/cluster/$CLUSTER_NAME\`]].ResourceArn"

# Delete LoadBalancers
lbs=$(aws elbv2 describe-load-balancers --output text --query 'LoadBalancers[].LoadBalancerArn')
arns=$(echo $lbs | xargs -n $BUFFER_SIZE aws elbv2 describe-tags --output text --query $CLUSTER_QUERY --resource-arns)
echo $arns | xargs -t -n 1 aws elbv2 delete-load-balancer --load-balancer-arn

# Delete TargetGroups
tgs=$(aws elbv2 describe-target-groups --output text --query 'TargetGroups[].TargetGroupArn')
arns=$(echo $tgs | xargs -n $BUFFER_SIZE aws elbv2 describe-tags --output text --query $CLUSTER_QUERY --resource-arns)
echo $arns | xargs -t -n 1 aws elbv2 delete-target-group --target-group-arn

# Delete EBS Volumes
vols=$(aws ec2 describe-volumes --output text --filters Name=tag:kubernetes.io/cluster/$CLUSTER_NAME,Values=owned --query 'Volumes[].VolumeId')
echo $vols | xargs -t -n 1 aws ec2 delete-volume --volume-id
