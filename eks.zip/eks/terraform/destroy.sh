#!/bin/bash

CLUSTER_NAME=$(terraform output eks_cluster_name)
terraform destroy -auto-approve
../cleanup.sh $CLUSTER_NAME
