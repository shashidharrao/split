#!/bin/bash

function version() {
  echo "$@" | awk -F. '{ printf("%d%03d%03d%03d\n", $1,$2,$3,$4); }';
}

function eks_verify_tools_installed() {
  AWSCLI_VERSION=`aws --version | cut -d" " -f1 | cut -d"/" -f2`
  if [ $(version $AWSCLI_VERSION) -lt $(version "1.16.156") ]; then
      echo "awscli installed version $AWSCLI_VERSION is older than required version 1.16.156"
      echo "Please run AWS@Apple setup again to ugrade."
      echo "Link: https://github.pie.apple.com/CloudTech/aws-apple/tree/master/setup"
      exit 1
  fi

  if ! [ -x "$(command -v kubectl)" ]; then
    echo "kubectl is not installed"
    echo "Please install kubectl and try again."
    echo "Link: https://kubernetes.io/docs/tasks/tools/install-kubectl/"
    exit 1
  fi

  if ! [ -x "$(command -v yq)" ]; then
    echo "yq is not installed"
    echo "Please install yq and try again."
    echo "Link: https://github.com/mikefarah/yq"
    exit 1
  fi
}

function eks_configure_kubeconfig() {
  aws eks --region ${AWS_REGION} update-kubeconfig --name ${CLUSTER_NAME}
}

function eks_configure_auth() {
  cat lib/cm-auth.yaml | envsubst | kubectl apply -f -
}

function eks_configure_proxy() {
  cat lib/cm-proxy.yaml | envsubst | kubectl apply -f -
  kubectl patch -n kube-system -p '{ "spec": {"template": { "spec": { "containers": [ { "name": "aws-node", "envFrom": [ { "configMapRef": {"name": "proxy-environment-variables"} } ] } ] } } } }' daemonset aws-node
  kubectl patch -n kube-system -p '{ "spec": {"template": { "spec": { "containers": [ { "name": "kube-proxy", "envFrom": [ { "configMapRef": {"name": "proxy-environment-variables"} } ] } ] } } } }' daemonset kube-proxy
  kubectl patch -n kube-system -p '{ "spec": {"template": { "spec": { "containers": [ { "name": "coredns", "envFrom": [ { "configMapRef": {"name": "proxy-environment-variables"} } ] } ] } } } }' deployment coredns
}

function eks_encrypt_storage_class() {
  is_encrypted=$(kubectl get storageclass gp2 -o jsonpath='{.parameters.encrypted}')
  if [  "$is_encrypted" == "true" ]; then
    kubectl get storageclass gp2 -o json | \
    jq ".parameters.encrypted = \"true\" | \
        .parameters.kmsKeyId=\"${EKS_ENCRYPTION_KEY}\"" | \
    kubectl replace --force -f -
  fi
}
